# Apache Calcite Tutorial

This repository contains code which demonstrate the use of Apache Calcite as a library for SQL query planning.

First part of the tutorial can be found [here](https://medium.com/@mpathirage/query-planning-with-apache-calcite-part-1-fe957b011c36).
